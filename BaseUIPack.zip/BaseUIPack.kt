package com.semseytech.modules.baseui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import claudia.shell.api.LauncherModule
import claudia.shell.api.SystemServices
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

/**
 * Base UI Pack - A clean, modern starter UI for Claudia Shell.
 * Built with Jetpack Compose.
 */
class BaseUIPack : LauncherModule {
    override val id: String = "base_ui_pack"
    override val name: String = "Base UI Pack"

    // Settings State
    private var blurBackground by mutableStateOf(true)
    private var roundedCorners by mutableStateOf(true)
    private var accentColor by mutableStateOf(Color(0xFF6200EE))
    private var themeMode by mutableStateOf("auto")
    private var currentMode by mutableStateOf("apps")

    override fun onInitialize() {
        // Initialization logic for the module
        println("Base UI Pack Initialized")
    }

    override fun onDestroy() {
        // Cleanup logic
        println("Base UI Pack Destroyed")
    }

    @Composable
    override fun HomescreenSurface() {
        val cornerRadius = if (roundedCorners) 24.dp else 0.dp
        
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Header Area
            HeaderSection()

            Spacer(modifier = Modifier.height(24.dp))

            // Quick Actions
            QuickActionsRow()

            Spacer(modifier = Modifier.height(24.dp))

            // Flexible Content Area
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .background(
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.8f),
                        shape = RoundedCornerShape(cornerRadius)
                    )
                    .padding(16.dp),
                contentAlignment = Alignment.Center
            ) {
                when (currentMode) {
                    "apps" -> Text("App Grid Placeholder", style = MaterialTheme.typography.bodyLarge)
                    "weather" -> Text("Weather Card Placeholder", style = MaterialTheme.typography.bodyLarge)
                    "notes" -> Text("Notes Card Placeholder", style = MaterialTheme.typography.bodyLarge)
                    "media" -> Text("Media Controls Placeholder", style = MaterialTheme.typography.bodyLarge)
                    else -> Text("Select a Mode")
                }
            }
            
            // Mode Switcher (Simple DSL implementation for UI)
            Row(
                modifier = Modifier.fillMaxWidth().padding(top = 16.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                listOf("apps", "weather", "notes", "media").forEach { mode ->
                    Button(
                        onClick = { currentMode = mode },
                        colors = if (currentMode == mode) ButtonDefaults.buttonColors(containerColor = accentColor) 
                                 else ButtonDefaults.filledTonalButtonColors()
                    ) {
                        Text(mode.replaceFirstChar { it.uppercase() })
                    }
                }
            }
        }
    }

    @Composable
    private fun HeaderSection() {
        val now = LocalDateTime.now()
        val timeFormatter = DateTimeFormatter.ofPattern("HH:mm")
        val dateFormatter = DateTimeFormatter.ofPattern("EEEE, MMM d")

        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = now.format(timeFormatter),
                style = MaterialTheme.typography.displayMedium,
                color = MaterialTheme.colorScheme.onBackground
            )
            Text(
                text = now.format(dateFormatter),
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f)
            )
            Text(
                text = "Battery: 85%",
                style = MaterialTheme.typography.labelLarge,
                color = accentColor
            )
        }
    }

    @Composable
    private fun QuickActionsRow() {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            QuickActionButton("WiFi", onClick = { SystemServices.wifi.toggle() })
            QuickActionButton("BT", onClick = { SystemServices.bluetooth.toggle() })
            QuickActionButton("Torch", onClick = { SystemServices.flashlight.toggle() })
        }
    }

    @Composable
    private fun QuickActionButton(label: String, onClick: () -> Unit) {
        FilledTonalButton(onClick = onClick) {
            Text(label)
        }
    }

    @Composable
    override fun SettingsPage() {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp)
        ) {
            Text("Base UI Pack Settings", style = MaterialTheme.typography.headlineMedium)
            
            Spacer(modifier = Modifier.height(16.dp))

            // Blur Toggle
            SettingsToggle("Blur Background", blurBackground) { blurBackground = it }
            
            // Rounded Corners Toggle
            SettingsToggle("Rounded Corners", roundedCorners) { roundedCorners = it }

            // Theme Mode
            Text("Theme Mode", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 16.dp))
            Row {
                listOf("light", "dark", "auto").forEach { mode ->
                    RadioButton(selected = themeMode == mode, onClick = { themeMode = mode })
                    Text(mode, modifier = Modifier.padding(top = 12.dp, end = 16.dp))
                }
            }
        }
    }

    @Composable
    private fun SettingsToggle(label: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(label, style = MaterialTheme.typography.bodyLarge)
            Switch(checked = checked, onCheckedChange = onCheckedChange)
        }
    }
}
